# Gowshikrajan
# 60307390
# INFS1101 - 16
# PicnicArithmetic

sandwichPrice = float(input("Enter the price of a sandwich: "))
drinkPrice = float(input("Enter the price of a drink: "))
sandwichNum = int(input("How many sandwiches are you buying? "))
drinkNum = int(input("How many drinks are you buying? "))

total_expense = (sandwichPrice * sandwichNum) + (drinkPrice * drinkNum)

print(f"Total expense for picnic is: {total_expense} QAR.")

