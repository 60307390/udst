# Gowshikrajan
# 60307390
# INFS 1101 - 16
# HiFiveHiEvenBye

n = int(input("Enter an integer: "))

if n % 5 == 0:
    print("HiFive")
if n % 2 == 0:
    print("HiEven")
