##
# Gowshikrajan Senthilkumar - 60307390
# Week11 lab
# Exercise 3

import random

def randomLetter():
    'returns a random lowercase letter'
    return chr(random.randint(97,122))
